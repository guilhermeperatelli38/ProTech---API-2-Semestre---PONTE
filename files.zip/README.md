<div align="center">

<img src="./assets/logo.png" width="180" alt="ProTech Logo" />

# ProTech — Integração & Resoluções Empresariais
### Projeto, Construção e Testes de Pontes

*"Projetar um futuro com ética"*

[![Status](https://img.shields.io/badge/status-em%20andamento-2ecc71?style=flat-square)]()
[![Metodologia](https://img.shields.io/badge/metodologia-Scrum-1F3864?style=flat-square)]()
[![Curso](https://img.shields.io/badge/curso-Engenharia%20de%20Produ%C3%A7%C3%A3o-C0392B?style=flat-square)]()
[![Instituição](https://img.shields.io/badge/institui%C3%A7%C3%A3o-FATEC%20SJC-555555?style=flat-square)]()
[![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)]()

</div>

---

## 📋 Sumário

- [Sobre o Projeto](#-sobre-o-projeto)
- [Desafio](#-desafio)
- [Equipe](#-equipe)
- [Requisitos e Especificações Técnicas](#-requisitos-e-especificações-técnicas)
- [Materiais e Métodos Permitidos](#-materiais-e-métodos-permitidos)
- [Restrições do Projeto](#-restrições-do-projeto)
- [Metodologia](#-metodologia)
- [Etapas do Projeto](#-etapas-do-projeto)
- [Cronograma](#-cronograma)
- [Estrutura do Repositório](#-estrutura-do-repositório)
- [Documentação](#-documentação)
- [Licença](#-licença)

---

## 🌉 Sobre o Projeto

Este repositório reúne toda a documentação, cálculos, desenhos técnicos e registros de fabricação do protótipo de ponte desenvolvido pela equipe **ProTech**, como parte da disciplina de **Projeto de API (Aprendizado por Projetos Integrados)** — 2º semestre de **Engenharia de Produção**, na **Faculdade de Tecnologia de São José dos Campos (FATEC-SJC)**.

O objetivo é aplicar, de forma integrada, conceitos de mecânica dos sólidos, seleção de materiais, fabricação, gestão de projetos e metodologias ágeis no desenvolvimento de uma solução estrutural real, avaliada por desempenho, economia de materiais, qualidade e segurança.

## 🎯 Desafio

> Desenvolver o protótipo de uma ponte apoiada entre dois pontos fixos separados por **80 cm de vão livre**, sem apoios intermediários, capaz de suportar uma carga mínima especificada, avaliada pela eficiência estrutural — relação entre a massa da ponte e a carga suportada — além do atendimento aos demais requisitos técnicos e restrições do projeto.

## 👥 Equipe

| Integrante | Papel |
|---|---|
| Rodrigo Nagy | Membro da equipe |
| Rafael Costa | Membro da equipe |
| **Guilherme Peratelli** | Product Owner |
| Luís Guilherme | Membro da equipe |
| Ian Fully | Membro da equipe |

## 📐 Requisitos e Especificações Técnicas

| Parâmetro | Especificação |
|---|---|
| Vão livre entre apoios | 80 cm |
| Apoios intermediários | Não permitidos |
| Comprimento máximo | 1 m |
| Largura | Entre 12 e 20 cm |
| Altura máxima | 40 cm |
| Tolerância dimensional | ± 1 cm |
| Massa máxima | 2 kg |
| Carga mínima suportada | 5 kg + suporte de ensaio (~1 kg), por 60 s sem colapso |
| Processo de união | Exclusivamente por colagem |
| Custo total dos materiais | Até R$ 100,00 |

## 🧱 Materiais e Métodos Permitidos

<details>
<summary><strong>Materiais para construção</strong></summary>

- Palitos de madeira, espetos/varetas de bambu, madeira em geral
- Papel, papel kraft, papel cartão, papelão ondulado, papelão Paraná, tubos de papel, embalagens cartonadas
- Plásticos em PVC (filetes)
- Barbante, fio e tecido de algodão, gaze, cortiça
- Materiais poliméricos reciclados de pequena espessura (PET, PEAD, etc.)

</details>

<details>
<summary><strong>Materiais para união</strong></summary>

- Cola PVA
- Cola para madeira
- Cola quente
- Cola epóxi

</details>

## 🚫 Restrições do Projeto

- Proibido o uso de barras/perfis/cabos metálicos, concreto, argamassa, peças prontas, impressão 3D, fibra de carbono/vidro industrial, chapas estruturais comerciais, parafusos, pregos, grampos ou rebites
- Proibido amarrar **e** colar a mesma união
- Proibido uso de parafusos ou pinos na montagem
- Proibida a construção como elemento maciço ou predominantemente maciço

## 🔄 Metodologia

A equipe adota a metodologia ágil **Scrum** para gestão e organização do projeto, com apoio das ferramentas:

- **5W2H** — planejamento e definição de ações
- **Análise SWOT** — avaliação de forças, fraquezas, oportunidades e ameaças

## 🗂️ Etapas do Projeto

```
Etapa 1 · Conceber      → pesquisa, requisitos, alternativas, escolha da solução
Etapa 2 · Projetar      → materiais, testes preliminares, croquis, cálculos
Etapa 3 · Implementar   → desenhos técnicos, memorial de cálculo, fabricação
Etapa 4 · Testar        → ensaio de carga, análise de falha, previsto × realizado
```

## 📅 Cronograma

| Data | Evento | Entrega |
|---|---|---|
| 24/08/2026 | Kick-off do projeto | Presencial na FATEC |
| 04/09/2026 | Validação do entendimento (Etapa 1) | Vídeo com proposta de solução |
| 25/09/2026 | Etapa 2 | Reunião com cliente |
| 30/10/2026 | Etapa 3 | Reunião com cliente |
| 23/11/2026 | Etapa 4 | Reunião com cliente + vídeo no YouTube |
| 03/12/2026 | Feira de Soluções | Apresentação presencial na FATEC |

## 📁 Estrutura do Repositório

```
protech-ponte/
├── assets/                  # Logo e imagens do projeto
├── docs/
│   ├── relatorio-conceitual.docx
│   ├── memorial-de-calculo.pdf
│   └── desenhos-tecnicos/
├── fabricacao/
│   ├── gabaritos/
│   └── registro-fotografico/
├── ensaios/
│   ├── plano-de-ensaios.md
│   └── resultados/
├── backlog/
│   └── sprint-backlog.md
└── README.md
```

## 📄 Documentação

Toda a documentação técnica de cada etapa — croquis, desenhos CAD, memorial de cálculo, lista de materiais, orçamento e registros de fabricação e ensaio — é versionada neste repositório, conforme exigido pela disciplina.

## 📜 Licença

Projeto acadêmico desenvolvido para fins educacionais na FATEC São José dos Campos. Distribuído sob licença [MIT](./LICENSE).

---

<div align="center">
<sub>Desenvolvido pela equipe <strong>ProTech</strong> — Engenharia de Produção, FATEC-SJC</sub>
</div>
